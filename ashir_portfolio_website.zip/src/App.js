
import React from "react";
import "./index.css";

export default function AshirPortfolio() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      <header className="bg-white shadow p-6">
        <h1 className="text-3xl font-bold text-center">Mohammed Ashir</h1>
        <p className="text-center text-lg text-gray-600">Accountant | Financial Analyst</p>
        <div className="text-center mt-4">
          <a
            href="/MOHAMMED__ASHIR__Accountant.pdf"
            download
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
          >
            Download CV
          </a>
        </div>
      </header>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-2">About Me</h2>
        <p>
          Highly skilled and detail-oriented Accountant with 3 years of expertise in
          financial management, reporting, accounts payable and receivable, and
          variance analysis. Proficient in QuickBooks, Tally ERP, and Microsoft Excel.
          Passionate about helping organizations maintain accurate financial records
          and make data-driven decisions.
        </p>
      </section>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-2">Experience</h2>
        <div className="mb-4">
          <h3 className="font-bold">Accounts Receivables – HKDC/Tahseel, Sharjah (Jan 2023 – Present)</h3>
          <ul className="list-disc ml-5">
            <li>Improved collection efficiency by streamlining follow-up processes</li>
            <li>Performed monthly financial reconciliations and variance analysis</li>
            <li>Maintained accurate customer records using accounting software</li>
          </ul>
        </div>
        <div>
          <h3 className="font-bold">Accountant – Al-Qumma lil Tamaez (Everest), Oman (Jun 2021 – Aug 2022)</h3>
          <ul className="list-disc ml-5">
            <li>Managed daily accounting operations and tax compliance</li>
            <li>Prepared financial reports and supported budgeting activities</li>
            <li>Used accounting tools to streamline processes and improve accuracy</li>
          </ul>
        </div>
      </section>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-2">Education</h2>
        <ul className="list-disc ml-5">
          <li>MBA – Amity University, Dubai (Jul 2022 – Jul 2024)</li>
          <li>Bachelor of Commerce – Mangalore University, India (May 2018 – Apr 2021)</li>
        </ul>
      </section>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-2">Certifications</h2>
        <ul className="list-disc ml-5">
          <li>QuickBooks Online Accountant (Mar 2024 – May 2024)</li>
          <li>Diploma in Financial Accounting (Jan 2022 – Nov 2021)</li>
        </ul>
      </section>

      <section className="p-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-2">Skills</h2>
        <div className="grid grid-cols-2 gap-4">
          <span>Financial Analysis</span>
          <span>Accounts Payable & Receivable</span>
          <span>QuickBooks & Tally ERP</span>
          <span>Microsoft Excel</span>
          <span>Tax Compliance</span>
          <span>GAAP Knowledge</span>
        </div>
      </section>

      <section className="bg-white p-6 max-w-4xl mx-auto mt-6 shadow">
        <h2 className="text-2xl font-semibold mb-2">Contact</h2>
        <p><strong>Email:</strong> <a href="mailto:mhdashir77@gmail.com" className="text-blue-600">mhdashir77@gmail.com</a></p>
        <p><strong>Phone:</strong> +971-588347839</p>
        <p><strong>Location:</strong> Sharjah, United Arab Emirates</p>
      </section>
    </div>
  );
}
